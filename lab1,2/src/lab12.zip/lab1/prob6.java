package lab1;

public class prob6 {
    public static void main(String[] args) {
        for (int i = 1; i < 10; i++){
            System.out.printf("%.2f \n", (double) 1/i);
        }
    }
}
