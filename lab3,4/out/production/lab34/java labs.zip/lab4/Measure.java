package lab4;

public enum Measure {
    кг,
    штука,
    литр;
}
