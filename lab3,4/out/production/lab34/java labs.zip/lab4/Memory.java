package lab4;

public class Memory {
    private int volume; //объем

    public Memory(int volume){
        this.volume = volume;
    }

    public int getVolume() {
        return volume;
    }
}
