package lab4;

public class Skirt extends Clothes implements WomenClothing{
    @Override
    public void dressWoman() {
    }
    @Override
    public void setName(){
        this.name = "Юбка";
    }
}
