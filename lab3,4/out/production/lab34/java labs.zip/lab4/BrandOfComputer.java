package lab4;

public enum BrandOfComputer {
    ASUS,
    Huawei,
    MACBook,
    HP;
}
