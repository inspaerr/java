package lab4;

public class Tie extends Clothes implements MenClothing{
    @Override
    public void dressMan() {
    }
    @Override
    public void setName(){
        this.name = "Галстук";
    }
}
