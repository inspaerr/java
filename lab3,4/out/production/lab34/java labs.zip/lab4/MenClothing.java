package lab4;

public interface MenClothing {
    public void dressMan();
}
