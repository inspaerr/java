package lab4;

public interface WomenClothing {
    public void dressWoman();
}
