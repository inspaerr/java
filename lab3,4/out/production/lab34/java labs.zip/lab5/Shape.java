package lab5;

import java.awt.*;

public abstract class Shape {
    int x, y, color_r, color_g, color_b;

    public void draw(Graphics g) {
    }

    ;
}

